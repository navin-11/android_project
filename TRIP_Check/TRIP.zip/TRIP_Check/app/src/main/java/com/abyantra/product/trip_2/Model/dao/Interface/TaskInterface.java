package com.abyantra.product.trip_2.Model.dao.Interface;

public interface TaskInterface {
}
