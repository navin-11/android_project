package com.abyantra.product.trip_2.Model.restmessage.task.request;

public class GetAllTaskRequest {
}
